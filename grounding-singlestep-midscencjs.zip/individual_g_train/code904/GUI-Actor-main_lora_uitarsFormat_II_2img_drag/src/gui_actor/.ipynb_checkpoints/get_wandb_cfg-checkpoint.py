
import os
import wandb

os.environ["WANDB_MODE"] = "offline"
WANDB_KEY = '39aea0a8e1ab23a8cb89feafb03371a44b13d644'
wandb.login(key=WANDB_KEY)
##### 离线的 wandb目录

def get_wandb(training_args):
        run = wandb.init(
        project='609',
        group='609',
        name='609_coordfree',
        dir=training_args.output_dir,
        settings=wandb.Settings(init_timeout=120)
        # config=args
    )
    return run