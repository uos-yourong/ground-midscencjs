import torch
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training


def find_target_linear_names(model,
                             num_lora_modules=-1,
                             lora_namespan_exclude=["self_attn", "lm_head", "vision_model", "img_projection",
                                                    "visual_model"],
                             verbose=True):
    linear_cls = torch.nn.modules.Linear
    lora_module_names = []
    # lora_namespan_exclude += ["vision_model", "img_projection", "visual_model"]
    for name, module in model.named_modules():
        if any(ex_keyword in name for ex_keyword in lora_namespan_exclude):
            continue
        if isinstance(module, linear_cls):
            lora_module_names.append(name)

    if num_lora_modules > 0:
        lora_module_names = lora_module_names[-num_lora_modules:]
    if verbose:
        print(f"Found {len(lora_module_names)} lora modules: {lora_module_names}")
    return lora_module_names

def get_model_peft_and_freeze(model,lora_r=64,lora_alpha=64,lora_dropout=0.05):
    exclude_module = ["visual"]

    ##### 把 llm decoder的 线性weight 分解成lora
    lora_target_modules = find_target_linear_names(model, lora_namespan_exclude=exclude_module)

    lora_config = LoraConfig(
        r=lora_r,
        lora_alpha=lora_alpha,
        target_modules=lora_target_modules,
        lora_dropout=lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    if 1:
        model.enable_input_require_grads()
        model.gradient_checkpointing_enable()

    # if not args.tune_visual_encoder:## 不微调视觉
    if 1:
        if lora_r > 0:
            for p in model.visual.parameters():
                p.requires_grad = False

    # Check trainable parameters
    list_of_params_to_optimize = []
    for n, p in model.named_parameters():
        if p.requires_grad:
            # if args.global_rank == 0:
            if 1:
                print("[Name]", n, " [Shape]", p.shape)
            list_of_params_to_optimize.append(p)
    return model,list_of_params_to_optimize
if __name__ == '__main__':
    lora_r = 8 * 2
    lora_alpha = 8 * 2
    lora_dropout = 0.05
    import sys

    sys.path.insert(0, '/root/autodl-tmp/train_code/code609/GUI-Actor-main/src/')
    from gui_actor.modeling import Qwen2VLForConditionalGenerationWithPointer

    # 假设你已经加载了模型
    model = Qwen2VLForConditionalGenerationWithPointer.from_pretrained(
        '/root/autodl-tmp/model_download_CoordFree_qwen2',
        # cache_dir='',
        # attn_implementation="flash_attention_2" if model_args.flash_attn_2_enabled else None,
        torch_dtype=torch.bfloat16,
        low_cpu_mem_usage=False,
    )

    # 获取模型的 state_dict
    state_dict = model.state_dict()

    if False:
        # 打印模型的名称和权重
        for name, param in state_dict.items():
            print(f"Name: {name}")
            print(f"Weight: {param}")
            print("------")


    get_model_peft_and_freeze(model,lora_r,lora_alpha,lora_dropout)

