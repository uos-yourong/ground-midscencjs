"""
基于[错误识别,错误原因] -> 下一步怎么修复


"""


REFLECT_COT_GENERATOR_PROMPT_FOR_MOUSE_ACTION_furtherResume = """Your task is to generate components: `Thought`, and `Action`, for some computer-use actions. 
These components must reason about the current state of the task based on the history and current screenshot, evaluate task progress. 
  

You are provided with the following information:
1. **Previous Actions**: A list of actions that have been taken so far. It is given in the form of pyautogui
2. **Reflection of the former incorrect or redundant action**: The reason why the former action was wrong or redundant.
3. **Goal**: A description of the task to be accomplished.
4. **Full Screenshot**:Screenshots showing the computer's latest two states. The second state is the wrong state that you accidentally entered and need to take action to return to the previous state.

**Previous Actions**:
{previous_actions}

**Reflection of the former incorrect or redundant action**:
{former_action_effect}

**Goal**: 
{goal}

### **Output**:
You must generate the following components:  
1. **Thought**:
    - Memory:
        - Add necessary information according to the history,  current screenshot.
    - Step by Step assess the progress towards completing the task:
        - Analyze what parts of the task have already been completed and how they contribute to the overall goal.
        - Adjust the former plan given the current incorrect state of screenshot.
    - Given current wrong state,propose the logical next action to correct the former mistake,go back to previous state and explain why:
        - The logical next action should match the current full screenshot
        - Anticipate the consequences of the logical next action (how the computer state will likely change after the action is performed).
    - Use the first-person perspective to represent the thought process.

2. **Action**:
    Provide a clear, actionable instruction based strictly on the logical next action. 
    - If the action involves interacting with a specific target (e.g., clicking, dragging), describe the target explicitly. Avoid directly using coordinates.
        - When clicking an element like an icon, specify the element's name whenever possible. If the element's name is not identifiable, describe its features like shape, color, position or relationship to other elements. 
        - When interacting with buttons in the top-right corner of an application window (e.g., minimize, maximize, close), ensure the target button is correctly identified. 
        - If clicking on a specific portion of text, describe where exactly the click occurred within the text.  
        - If the click position corresponds to an empty space, it may serve purposes such as closing a pop-up, refocusing a window, or dismissing a modal.

### **Important Notes**:
Respond in strict accordance with the required format. No extra text, no additional sections beyond this structure:

## Thought:
thought(in Chinese language)

## Action:
action(in Chinese language)
""".strip()