
####### 这是论文中的  没有COT 思考  过于简单 思考和 VIS结合渗透不明显,
### 是否考虑用API 生成 COT 在推演出output
### api_img_desc
prompt_template="""
Please generate the next action and the previous n(1) action according to the previous UI screenshot, current UI screenshot, instruction and history actions.
You are given two images,the first one is previous UI screen and the second one is current UI screen.
Below is instruction and history actions.
# Task:
{instruction}

# History steps:
{history_steps}

## Output Format
```
Next action:...
Previous n(1) action:..."""
def get_prompt_backtrack(instruction,history):
    user_prompt = prompt_template.format(
        instruction=instruction,
        history_steps=history
    )
    return user_prompt




