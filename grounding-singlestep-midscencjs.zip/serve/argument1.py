
import argparse





def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--step', default=None, type=str)
    parser.add_argument('-n', '--savename', default=None, type=str)
    return parser.parse_args()
