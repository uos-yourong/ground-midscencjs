import os
import requests
from PIL import Image
import io
import re
import base64
from pathlib import Path

def get_image_dimensions(image_input):
    """
    获取图像的宽高，支持本地PNG文件、URL 和 base64 Data URI
    
    参数:
        image_input: 可以是本地文件路径、URL 或 base64 Data URI
        
    返回:
        tuple: (width, height) 或 None（如果获取失败）
    """
    
    # 判断输入类型
    if is_data_uri(image_input):
        print(f"检测到Base64 Data URI输入")
        return get_dimensions_from_data_uri(image_input)
    elif is_http_url(image_input):
        print(f"检测到HTTP URL输入: {image_input}")
        return get_dimensions_from_url(image_input)
    elif is_local_file(image_input):
        print(f"检测到本地文件: {image_input}")
        return get_dimensions_from_local(image_input)
    else:
        print(f"无法识别输入类型: {image_input}")
        return None

def is_data_uri(input_str):
    """判断是否为Data URI (base64格式)"""
    return input_str.startswith('data:image/')

def is_http_url(input_str):
    """判断是否为HTTP/HTTPS URL"""
    return input_str.startswith(('http://', 'https://'))

def is_local_file(input_str):
    """判断是否为本地文件路径"""
    # 检查是否为文件路径格式
    if os.path.sep in input_str or (os.path.altsep and os.path.altsep in input_str):
        # 检查文件扩展名是否为图像格式
        valid_extensions = ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff', '.webp']
        file_ext = os.path.splitext(input_str)[1].lower()
        if file_ext in valid_extensions:
            # 检查文件是否存在
            return os.path.exists(input_str)
    
    # 如果是当前目录下的文件
    if os.path.exists(input_str) and os.path.isfile(input_str):
        valid_extensions = ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff', '.webp']
        file_ext = os.path.splitext(input_str)[1].lower()
        if file_ext in valid_extensions:
            return True
    
    return False

def get_dimensions_from_data_uri(data_uri):
    """从Data URI (base64) 获取图像尺寸"""
    try:
        # 解析Data URI格式: data:image/png;base64,xxxx 或 data:image/jpeg,xxxx
        if ',' not in data_uri:
            print("无效的Data URI格式: 缺少逗号分隔符")
            return None
        
        # 分离header和base64数据
        header, base64_data = data_uri.split(',', 1)
        
        # 检查是否包含base64标记
        if 'base64' in header:
            # 标准的base64编码
            image_data = base64.b64decode(base64_data)
        else:
            # 可能是URL编码，尝试直接解码
            import urllib.parse
            image_data = urllib.parse.unquote_to_bytes(base64_data)
        
        # 使用PIL打开图像
        image = Image.open(io.BytesIO(image_data))
        width, height = image.size
        print(f"从Data URI获取图像尺寸: {width} x {height}")
        return width, height
        
    except base64.binascii.Error as e:
        print(f"Base64解码失败: {e}")
        return None
    except Exception as e:
        print(f"处理Data URI时出错: {e}")
        return None

def get_dimensions_from_url(url):
    """从HTTP URL获取图像尺寸"""
    try:
        # 发送HTTP请求获取图像
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()  # 检查请求是否成功
        
        # 检查内容类型是否为图像
        content_type = response.headers.get('content-type', '')
        if not content_type.startswith('image/'):
            print(f"警告: URL返回的内容类型不是图像: {content_type}")
        
        # 使用PIL打开图像
        image = Image.open(io.BytesIO(response.content))
        
        width, height = image.size
        print(f"从URL获取图像尺寸: {width} x {height}")
        return width, height
        
    except requests.exceptions.RequestException as e:
        print(f"URL请求失败: {e}")
        return None
    except Exception as e:
        print(f"处理URL图像时出错: {e}")
        return None

def get_dimensions_from_local(file_path):
    """从本地文件获取图像尺寸"""
    try:
        # 检查文件是否存在
        if not os.path.exists(file_path):
            print(f"文件不存在: {file_path}")
            return None
        
        # 检查文件扩展名
        file_ext = os.path.splitext(file_path)[1].lower()
        if file_ext != '.png':
            print(f"注意: 文件扩展名不是PNG: {file_ext}")
        
        # 使用PIL打开图像
        with Image.open(file_path) as img:
            width, height = img.size
            print(f"从本地文件获取图像尺寸: {width} x {height}")
            return width, height
            
    except FileNotFoundError:
        print(f"文件未找到: {file_path}")
        return None
    except Exception as e:
        print(f"处理本地图像时出错: {e}")
        return None


# 使用示例
if __name__ == "__main__":
    # 测试1: HTTP URL
    url = "https://example.com/image.png"
    result = get_image_dimensions(url)
    
    # 测试2: Base64 Data URI
    base64_png = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=="
    result = get_image_dimensions(base64_png)
    
    # 测试3: HTTPS URL
    https_url = "https://example.com/image.jpg"
    result = get_image_dimensions(https_url)