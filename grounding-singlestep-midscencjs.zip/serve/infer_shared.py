import torch
import json,re
import sys,copy
#sys.path.insert(0,'/root/autodl-tmp/train_code/code805/GUI-Actor-main_lora_616_uitarsFormat_II_2img/src')
#sys.path.insert(0,'/root/autodl-tmp/train_code/code826/GUI-Actor-main_lora_uitarsFormat_II/src')
sys.path.insert(0,'/data/yr/code/individual_g_train/code_904/GUI-Actor-main_lora_uitarsFormat_II_2img_drag/src')
from qwen_vl_utils import process_vision_info
from datasets import load_dataset
from transformers import AutoProcessor
#from gui_actor.constants import chat_template,guiact_action_system_message, grounding_system_message
from gui_actor.prompts_uitars import  get_prompt_uitars,get_prompt_uitars_noThought
from gui_actor.modeling import Qwen2VLForConditionalGenerationWithPointer
from gui_actor.inference_2img import inference
import os

from gui_actor.prompts_opencua import get_cotL1,get_cotL2,get_cotL3,get_reflect1
opencua_cotflag2fn={"action_opencuaL1":get_cotL1,
                    "action_opencuaL2":get_cotL2,
                    "action_opencuaL3":get_cotL3}
cotflag="action_opencuaL2"
get_prompt_fn_a=[get_prompt_uitars,opencua_cotflag2fn["action_opencuaL2"]][1]
get_prompt_fn_g_individual=get_prompt_uitars_noThought


# def change_role(conv):
#     roles = {"human": "user", "gpt": "assistant", "system": "system"}
#     role = conv['role'] if 'role' in conv else conv['from']
#     role = roles.get(role, role)
#     return role


def get_data_process(model_name_or_path):
    return AutoProcessor.from_pretrained(model_name_or_path)
def get_model(model_name_or_path):
    return Qwen2VLForConditionalGenerationWithPointer.from_pretrained(
        model_name_or_path,
        torch_dtype=torch.bfloat16,
        device_map="cuda:0",
        attn_implementation="flash_attention_2"
    ).eval()
def make_history_cell(h):
    return {
        "from": "gpt",
        "value": h,  # "history1 thought1",
        "loss_mask": 0
    }
def make_image_cell():
    return {
        "from": "human",
        "value": "<image> ",
        "loss_mask": 0
    }
def get_imgbase64_content(encoded_string,min_pixels=256,max_pixels=3300*28*28,role='user'):
    return {
        "role": role,
        "content": [
            {
                "type": "image",
                "image": f"data:image/png;base64,{encoded_string}",
                "min_pixels": min_pixels,
                "max_pixels": max_pixels,

            }]}
def make_dragEnd_cell():
    drag_prefix= '拖拽动作已经预测起点，现在预测终点'
    return {
        "from": "human",
        "value": drag_prefix,
        "loss_mask": 0
    }
def get_conversation_imgbase64(task,convs,png=None,encoded_string_img=None,base64flag=True):### 参考os-world agent 历史 处理
    """
    1张图历史的
    uitars
    message输入顺序： [系统提示词 + 任务] + [历史...] + 图
    convs提供顺序，
    其中内容,文本内容在里面，而图片内容在别处：  历史1 历史2...   图
    """
    #### 组装系统提示词+任务
    #system_message_task = get_prompt_uitars(task)
    sys_message_task=get_prompt_fn(task)
    messages = [
        {
            "role": "system",
            "content": [{"type": "text", "text": "You are a helpful assistant."}]
        },
        {
            "role": "user",
            "content": [{"type": "text", "text": system_message_task}]
        }]
    ######  历史1 历史2...  图
    for conv in convs:
        value=conv['value']
        lossmask=conv['loss_mask']
        if lossmask==0 and '<image>' not in value:# history
            history_response=value
            his={
                "role": "assistant",
                "content": [{"type": "text",
                             "text":  history_response}]
            }
            messages.append(his)
        if '<image>' in value:
            if not base64flag :
                #cur_image=os.path.join(inputImgdir,png)
                cur_image=png
                messages.append(
                    {
                    "role": "user",
                    "content": [{ "type": "image",
                                  "image": cur_image}]}
                )
            else:
                messages.append(get_imgbase64_content(encoded_string_img))
    return messages

def get_system_message_task(task,name):
    if name=='individual_g':
        get_prompt_fn=get_prompt_fn_g_individual
        system_message_task=get_prompt_fn(task)
        return system_message_task
    else :
        get_prompt_fn = get_prompt_fn_a
        system_message_task = get_prompt_fn(task)
        return system_message_task

def get_message2_conversation_imgbase64(system_message_task,convs,encoded_string_img_list,uitarsPrompt_flag=False):### 参考os-world agent 历史 处理
    """2 张图
    输入顺序： 系统提示词 + 任务 + 历史 + 图"""
    roles = {"human": "user", "gpt": "assistant", "system": "system"}
    if type(encoded_string_img_list)!=list:
        pngll=[encoded_string_img_list]
    else:
        pngll=encoded_string_img_list
    #### 组装系统提示词+任务
    #system_message_task = get_prompt_uitars(task)
    #system_message_task = get_prompt_fn(task) if uitarsPrompt_flag==False else get_prompt_fn_g_individual(task)
    messages = [
        {
            "role": "system",
            "content": [{"type": "text", "text": "You are a helpful assistant."}]
        },
        {
            "role": "user",
            "content": [{"type": "text", "text": system_message_task}]
        }]
    img_ix=0
    for conv in convs:
        value=conv['value']
        lossmask=conv['loss_mask']
        role=conv['role'] if 'role' in conv else conv['from']
        role=roles.get(role,role)#### 转换 role
        if lossmask==0 and '<image>' not in value:# history
            history_response=value
            his={
                #"role": "assistant",
                "role":role,
                "content": [{"type": "text",
                             "text":  history_response}]
            }
            messages.append(his)
        if '<image>' in value:
            png=pngll[img_ix]### encode string
            encoded_string_img=png
            img_ix+=1
            #cur_image=os.path.join(inputImgdir,png)
            # messages.append(
            #     {
            #     #"role": "user",
            #         "role":role,
            #     "content": [{ "type": "image",
            #                  "image": cur_image,
            #                  "max_pixels": 28*28*3300,
            #                 }]}
            # )
            messages.append(get_imgbase64_content(encoded_string_img))
    return messages
def make_history(historyll,imagelist,drag_prefix=False):
    ### history
    # 顺序 sys+task, history,...,imgPre,history,imgCurrent,->output
    ll = []
    historyll_pre, historyll_last = historyll[:-1], historyll[-1:]
    ### 不包括最后一个的历史
    for h in historyll_pre:
        ll.append(make_history_cell(h))
        # ll.append({
        #     "from": "gpt",
        #     "value": h,  # "history1 thought1",
        #     "loss_mask": 0
        # })
    ##### 图片 imgPre
    if len(imagelist) > 1:
        ll.append(make_image_cell())
        # ll.append({
        #     "from": "human",
        #     "value": "<image> ",
        #     "loss_mask": 0
        # })
    ### 最后一个历史
    for h in historyll_last:
        ll.append(make_history_cell(h))
        # ll.append({
        #     "from": "gpt",
        #     "value": h,  # "history1 thought1",
        #     "loss_mask": 0
        # })
    ### 图片   current img
    ll.append(make_image_cell())
    # ll.append({
    #     "from": "human",
    #     "value": "<image> ",
    #     "loss_mask": 0
    # })
    ### 拖拽终点提示
    if drag_prefix:
        ll.append(make_dragEnd_cell())
        # ll.append({
        #     "from": "human",
        #     "value": drag_prefix,
        #     "loss_mask": 0
        # })
    #print('infer shared 186',ll)
    return ll


eos_token_id_map={'uitars':151645,
              'coordfree':151658}
def infer_result(conversation,model,tokenizer,data_processor,assistant_start_placeholder,EOSname):
    return inference(conversation,
              model,
              tokenizer,
              data_processor,
              use_placeholder=assistant_start_placeholder, topk=3,
                    EOS=eos_token_id_map[EOSname])


def get_predict_text(pred):
    if type(pred)==list:pred=pred[0]#### drag的情况
    return pred['output_text']
# def get_predict_pos(pred):
#     if pred["topk_points"]:###有交互对象位置
#         pos= pred["topk_points"][0]
#         px, py=pos
#         return px,py
#     else:return None### 无交互对象位置


def get_predict_pos_(pred):

    if type(pred) == dict:###  不是drag
        pred=[pred]
        # print(pred['output_text'])
        # pred = [pred]

    elif type(pred) == list:

        for pred_ in pred:
            print(pred_['output_text'], pred_["topk_points"])
    ####
    px, py, px1, py1 = None, None, None, None
    if len(pred) == 1 and pred[0]["topk_points"]:  ### 不是 键盘操作 ，有交互对象coord
        px, py = pred[0]["topk_points"][0]
        # if False:
        #     print(f"Predicted click point: [{round(px, 4)}, {round(py, 4)}]")

    elif len(pred) > 1 and pred[0]["topk_points"] and pred[1]["topk_points"]:
        px, py = pred[0]["topk_points"][0]
        px1, py1 = pred[1]["topk_points"][0]
    return [px,py],[px1,py1]

def get_predict_pos_noPH(predtxt):
    def get_point_from_txt_drag(text):
        x,y,x1,y1=None,None,None,None
        # 匹配 start_box 的坐标
        start_pattern = r"start_box='<\|box_start\|>\(x=([\d.]+),\s*y=([\d.]+)\)<\|box_end\|>'"
        start_match = re.search(start_pattern, text)
        if start_match:
            start_x, start_y = start_match.group(1), start_match.group(2)
            print(f"start_box 坐标: ({start_x}, {start_y})")
            x=float(start_x)
            y=float(start_y)

        # 匹配 end_box 的坐标
        end_pattern = r"end_box='<\|box_start\|>\(x=([\d.]+),\s*y=([\d.]+)\)<\|box_end\|>'"
        end_match = re.search(end_pattern, text)
        if end_match:
            end_x, end_y = end_match.group(1), end_match.group(2)
            print(f"end_box 坐标: ({end_x}, {end_y})")
            x1 = float(end_x)
            y1 = float(end_y)
        return  x,y,x1,y1

    ####
    predtxt=predtxt['output_text']
    px, py, px1, py1=get_point_from_txt_drag(predtxt)


    return [px,py],[px1,py1]