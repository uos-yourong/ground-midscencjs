from flask import Flask, request, jsonify
import base64
from PIL import Image
import io
import torch
from argument1 import get_args
from determine_img_type import get_image_dimensions
from util1.fake_openai_response import construct_fake_openaiResponse
from util1.uitars_action_mapper import map_action
from util1.qwenvl_result_format import get_qwenvl_rst_box
"""
1 grouding
2 action 其中drag如何出现  在推理一次
3 step Identify
based on [demo_infer1_1sample_g_a.py]

<|im_start|>assistant<|recipient|>os\n
<|im_end|>
123
456

midsc发送来的请求 什么样 解析出来 img text
预测结果
将结果 变成 fake openai response 返回给midsc

由于 MIDSCENJS 对不同的 default | plan | insight有不同 提示词 和  结果解析函数，分别处理
"""
app = Flask(__name__)
import sys,re
#sys.path.insert(0,'/root/autodl-tmp/train_code/code616/GUI-Actor-main_lora_616/eval')
from infer_shared import (get_data_process,
                                    get_model,
                                   get_conversation_imgbase64,
                                   #system_message_map,
                                   infer_result,
                                   get_predict_text,
                                   get_predict_pos_noPH,
                          make_image_cell,
                          #make_history_cell,
                          make_dragEnd_cell,
                          make_history,
                          get_message2_conversation_imgbase64,
get_system_message_task

                          )

def get_task(text):
    print('get task',text)
    #print(done)
    pattern1 = r'##\s*User Instruction\s*\n\s*(.*)$'
    match = re.search(pattern1, text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return None
#from message_mk_identifyError import get_message2_conversation_imgbase64 as get_message2_conversation_imgbase64_reflect
#from message_mk_identifyError import match_error


def extract_and_log_image_dimensions(messages):
    """
    从 messages 中提取图片（base64 格式），获取宽高，并记录到日志文件。
    返回一个包含所有提取到的图片宽高信息的列表。
    获取 instruction
    """
    image_info_list = []
    instruction=None
    image_url=None
    uitars_prompt_flag=True
    for msg in messages:
        #if msg.get("role") == "user" and isinstance(msg.get("content"), list):
        if msg.get("role") == "user":
            content=msg["content"]
            if type(content)==list:
                for content_item in msg["content"]:
                    #if not (type(content_item)==dict and 'type' in content_item):continue
                    if content_item.get("type") == "image_url":
                        image_url = content_item.get("image_url", {}).get("url", "")
                        print('image_url',image_url[:100])
                        #print(done1)
                        width,height=get_image_dimensions(image_url)
                        print(width,height)
                        #print(done1)

                        image_info = {
                                "width": width,
                                "height": height
                            }
                        image_info_list.append(image_info)
                    elif content_item.get("type") == "text":

                        wll=['Find: ','Find section containing: ' ]
                        for w in wll:
                            if w in content_item['text']:
                                uitars_prompt_flag=False
                                text=content_item['text'].replace('Find section containing: ','')
                                instruction=text
            elif type(content)==str: ### 当 agent.aiAct的时候 这个是 uitar 提示词
                
                ### midscenc的提示词不对 是box的 替换
                instruction=get_task(content)

                print(print('63 text',instruction))
                   
    print('mid serve 70',instruction,image_info_list)
    return {'wh':image_info_list,'prompt':instruction,'img_url':image_url,'uitars_prompt_flag':uitars_prompt_flag}
from metric_util import (get_w_h,
                       floatpoint2int)
                      # find_actionType,
                       #find_actionValue,
                      #category1,category2,category3,category4,category5,category6,
                       #drag_end_prompt_addition


args=get_args()
date=711

step=args.step
savename=args.savename

##model_name_or_path=f'/root/autodl-tmp/save{date}/{savename}/checkpoint-{step}/merged'
model_name_or_path=f'/data/yr/saved/{savename}/checkpoint-{step}/merged'
##/data/saved/sft_uos_warmGroundBase_data1125G/checkpoint-16000/merged
 
data_processor = get_data_process(model_name_or_path)
tokenizer = data_processor.tokenizer
model = get_model(model_name_or_path)
EOS_name=['uitars','coordfree'][0]


API_KEY = 'uos-testing-2b34'

@app.before_request
def before_request():
    api_key = request.headers.get('X-API-KEY')
    api_key=request.headers.get('Authorization').replace('Bearer ','')
     
    print('request key',api_key)
    if api_key != API_KEY:
        return jsonify({'error': 'Unauthorized'}), 401

#@app.route('/action', methods=['POST'])
@app.route('/v1/chat/completions', methods=['POST'])### openai client发的请求
@torch.inference_mode()
def chat_completions(): # sys+instr + hisN...+ his2+ img2 + his1 + img1(current)
    """
    拦截 /v1/chat/completions 请求，提取图片宽高。
    """
    #参考 mk_meta_CoordFree_manual_multistep_manualThought_notplanfirst2uitarFormat_sys2reThought_newhis_2img.py
    # 获取JSON数据
    data = request.json
    messages = data.get("messages", [])
    if 1:#### 看发来请求的 message格式
        import datetime
        with open('./midsc_req_message_aiAssert.log', 'a') as w:
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            w.write(f'[{timestamp}]\n')
            w.write(str(messages))
            w.write('\n\n')  # 空行分隔不同次请求
        #print(done1)
        
        # 1. 提取图片宽高并记录
    image_dimensions = extract_and_log_image_dimensions(messages)
    utiars_prompt_flag=image_dimensions['uitars_prompt_flag']#### 这个觉得 midsc的解析函数用什么，用uitars输出格式还是别的
    wh=image_dimensions['wh'][0]
    w,h=wh['width'],wh['height']
    instruction=image_dimensions['prompt']
    img_url=image_dimensions['img_url']
    print(130,img_url[:100],len(img_url.split(',')[-1]),instruction)#### data:image/png;base64,iVBORw0KGgoA
    img_url=img_url.split(',')[-1]####  iVBORw0KGgoA 必须是4的倍数
    #print(done1)
    data={'image':img_url,'obj':instruction,'w':w,'h':h,'history':[]}

    # # 检查数据是否包含必要的字段
    if 'image' not in data or 'obj' not in data:
        return jsonify({'error': 'Missing image or task field'}), 400

    # 获取图片和任务
    image_base64_list = data['image']
    if type(image_base64_list)!=list:image_base64_list=[image_base64_list]

   
    print('img list ',len(image_base64_list))
    task = data['obj']
    instruction=task
    w,h=data['w'],data['h']
    historyll=data['history']
    historyll=[f'history:{his}' for his in historyll]
    
    ### 类似 mk_xxxx.py中
    ### convs
    # convs = [make_history_cell(h) for h in historyll[:-1]]
    # convs += [make_image_cell()]
    convs=make_history(historyll,image_base64_list)

    assistant_start_placeholder = False  ##
    #### 类似dataset.py中
    system_message_task=get_system_message_task(instruction,'individual_g')
   
    conversation = get_message2_conversation_imgbase64(system_message_task,
                                             # system_message=system_message_map['action'],
                                              convs,
                                             encoded_string_img_list=image_base64_list,
                                            #uitarsPrompt_flag=True
                                                       )
    pred = infer_result(conversation, 
                        model, 
                        tokenizer, 
                        data_processor,
                        assistant_start_placeholder,
                        EOSname=EOS_name)
    
    ### 从文本中解析 thought action->actiontype ,value
    text = get_predict_text(pred)## 只判断是否有drag ，具体parse去agent地方完成
    print('serve g',text)
    text=text.replace('<|im_start|>assistant<|recipient|>os','').replace('<|im_end|>','')
    # actionType = find_actionType(text)
    dragflag=False if 'drag(' not in text else True

    if dragflag:
        pos_norm_start,pos_norm_end = get_predict_pos_noPH(pred)
        pos_pyautogui_start = floatpoint2int(w, h, pos_norm_start)
        pos_pyautogui_end = floatpoint2int(w, h, pos_norm_end)
        ### pyautogui -> uitars pred coord
        pos_uitars1=[pos_pyautogui_start[0]*1000/w,pos_pyautogui_start[1]*1000/h,
                            pos_pyautogui_end[0]*1000/w,pos_pyautogui_end[1]*1000/h]
        pos_uitars1=[int(v) for v in pos_uitars1]
        assert len(pos_uitars1)==4


        retdict = {'text': text, 'position_start': pos_pyautogui_start, 'position_end': pos_pyautogui_end}### 整数坐标
    # #### 按照不同action type 提取 动作属性
    # if  'drag_start' in text:
    #     ### drag start
    #     pos_norm_start = get_predict_pos(pred)
    #     ### drag end
    #     #convs+=[make_dragEnd_cell()]
    #     convs=make_history(historyll,image_base64_list,drag_prefix=True)
    #     conversation = get_message2_conversation_imgbase64(instruction,
    #                                               convs,
    #                                               #system_message=system_message_map['action'],
    #                                               encoded_string_img_list=image_base64_list)
    #     pred = infer_result(conversation,
    #                         model,
    #                         tokenizer,
    #                         data_processor,
    #                         assistant_start_placeholder,
    #                        EOSname=EOS_name)
    #     pos_norm_end = get_predict_pos(pred)
    #     pos_start = floatpoint2int(w, h, pos_norm_start)
    #     pos_end = floatpoint2int(w, h, pos_norm_end)
    #     #actiondict = {'actionType': 'drag', 'position_start': pos_start, 'position_end': pos_end}
    #     retdict={'text':text,'position_start': pos_start, 'position_end': pos_end}
    else:###非拖拽
        pos_pyautogui=None
        pos_uitars1=None
        pos_norm,_ = get_predict_pos_noPH(pred)

        if None in pos_norm:
            retdict={'text':text }
        else:
            pos_pyautogui = floatpoint2int(w, h, pos_norm)## pyautogui xy
            #### pyautogui coord -> uitars pred coord
            pos_uitars1=[pos_pyautogui[0]*1000/w,pos_pyautogui[1]*1000/h]
            pos_uitars1=[int(v) for v in pos_uitars1] +[None,None]### 起始点 结束点
            assert len(pos_uitars1)==4
            retdict = {'text': text,'position':pos_pyautogui}


    # 返回JSON响应
    #log1 = getlog()
    ##### 将文本中Action部分去掉 重新拼接 thought ....action....
    ### 其中action 可能 = click + type
    ###### 如果是 uitars prompt 对应的结果解析
    text_act_part= text.strip().split('Action:')[-1]###
    text_act_part=text_act_part.split('\n')
    text_act_part='\n\n'.join([map_action(text_act_part_i, pos_uitars1) for text_act_part_i in text_act_part])
    response_text='Thought:None\nAction:'+ text_act_part 
    print(253,retdict)
    print(254,[response_text])
    ####### 如果是 qwenvl prompt 结果对应的解析
    print('utiars_prompt_flag,pos_pyautogui',utiars_prompt_flag,pos_pyautogui)
    
    if utiars_prompt_flag==False:### 结果解析是 bbox:[1, 2, 3, 4]
        if pos_pyautogui:
            #box=pos_pyautogui+pos_pyautogui
            box=pos_uitars1[:2]+pos_uitars1[:2]
            response_text=get_qwenvl_rst_box(box)
            print('非uitars prompt的',response_text)
    # return jsonify({'action_output': retdict,
    #                 'info':f'ver({model_name_or_path})'})
    fake=construct_fake_openaiResponse(response_text)
    return jsonify(fake.model_dump())


if __name__ == '__main__':
    app.run(debug=True,port=6013,host='0.0.0.0',use_reloader=False)
    ### http://127.0.0.1:6006  -> https://u468127-b882-86bb84ef.westx.seetacloud.com:8443
    ### https://u468127-a595-0dc6183b.westx.seetacloud.com:8443

    ### CUDA_VISIBLE_DEVICES=0 python serve_g.py

     
