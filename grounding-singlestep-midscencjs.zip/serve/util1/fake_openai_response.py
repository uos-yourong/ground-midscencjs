from openai.types.chat import ChatCompletion, ChatCompletionMessage
from openai.types import CompletionUsage
from openai.types.chat.chat_completion import Choice
import time

def construct_fake_openaiResponse(text):
# 构造一个完整的 ChatCompletion 对象
    fake_response = ChatCompletion(
    id="chatcmpl-mock123456789",
    object="chat.completion",
    created=int(time.time()),
    model="ui-tars",
    choices=[
        Choice(
            index=0,
            message=ChatCompletionMessage(
                role="assistant",
                #content="这是一个模拟的响应内容",
                content=text,
                refusal=None
            ),
            finish_reason="stop",
            logprobs=None
        )
    ],
    usage=CompletionUsage(
        prompt_tokens=100,
        completion_tokens=50,
        total_tokens=150
    ),
    system_fingerprint="fp_mock123"
)
    return fake_response


if __name__=='__main__':
    # 使用方式与真实 API 完全一致
    print(fake_response.choices[0].message.content)
    print(fake_response.usage.total_tokens)