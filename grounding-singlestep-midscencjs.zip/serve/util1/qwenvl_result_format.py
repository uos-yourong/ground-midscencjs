import json


p="""
```json
{
"bbox":[],
"references_bbox":p[]
}
```
"""
def get_qwenvl_rst_box(box):
    data = [
        {
            "bbox": box,
            "references_bbox": []
        }
    ]
    s=json.dumps(data)
    return f"""```json\n{s}```"""