#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UI-TARS Action 字符串映射器

将 UI-TARS 的 action 字符串从原始格式映射为目标格式，
使用外部提供的坐标替换原始坐标。

映射规则:
- click(start_box='...') → click(start_box=(x1,y1))
- drag(start_box='...', end_box='...') → drag(start_box=(x1,y1), end_box=(x2,y2))
- type(content='...') → type(content='...') (保持不变)
- scroll(start_box='...', direction='...') → scroll(start_box=(x1,y1), direction='...')
- hotkey(key='...') → hotkey(key='...') (空格替换为 +)
- wait() → wait() (保持不变)
- finished(content='...') → finished(content='...') (保持不变)
"""

import re
from typing import Optional, Tuple


def map_action(
    action_str: str,
    pos_uitars:list,
    # x1: int,
    # y1: int,
    # x2: Optional[int] = None,
    # y2: Optional[int] = None
) -> str:
    """
    将单个 UI-TARS action 字符串映射为目标格式
    
    Args:
        action_str: 原始 action 字符串
        x1: 起始点/点击点的 x 坐标
        y1: 起始点/点击点的 y 坐标
        x2: 结束点的 x 坐标 (仅 drag 操作需要)
        y2: 结束点的 y 坐标 (仅 drag 操作需要)
    
    Returns:
        映射后的 action 字符串
    """
    x1,y1,x2,y2=pos_uitars
    action_str = action_str.strip()
    
    if not action_str:
        return action_str
    
    # 1. 处理 click(start_box='...')
    if action_str.startswith('click('):
        return f"click(start_box='({x1},{y1})')"
    
    # 2. 处理 left_double(start_box='...')
    if action_str.startswith('left_double('):
        return f"left_double(start_box='({x1},{y1})')"
    
    # 3. 处理 right_single(start_box='...')
    if action_str.startswith('right_single('):
        return f"right_single(start_box='({x1},{y1})')"
    
    # 4. 处理 drag(start_box='...', end_box='...')
    if action_str.startswith('drag('):
        if x2 is None or y2 is None:
            raise ValueError("drag 操作需要提供 x2, y2 坐标")
        return f"drag(start_box='({x1},{y1})', end_box='({x2},{y2})')"
    
    # 5. 处理 type(content='...')
    if action_str.startswith('type('):
        # 提取 content 内容
        match = re.search(r"content=['\"](.+?)['\"]", action_str, re.DOTALL)
        if match:
            content = match.group(1)
            return f"type(content='{content}')"
        return action_str
    
    # 6. 处理 scroll(start_box='...', direction='...')
    if action_str.startswith('scroll('):
        # 提取 direction
        match = re.search(r"direction=['\"](.+?)['\"]", action_str)
        if match:
            direction = match.group(1)
            return f"scroll(start_box='({x1},{y1})', direction='{direction}')"
        return f"scroll(start_box='({x1},{y1})')"
    
    # 7. 处理 hotkey(key='...')
    if action_str.startswith('hotkey('):
        # 提取 key 并替换空格为 +
        match = re.search(r"key=['\"](.+?)['\"]", action_str)
        if match:
            key = match.group(1).replace(' ', '+')
            return f"hotkey(key='{key}')"
        return action_str
    
    # 8. 处理 wait()
    if action_str.startswith('wait('):
        return "wait()"
    
    # 9. 处理 finished(content='...')
    if action_str.startswith('finished('):
        match = re.search(r"content=['\"](.*?)['\"]", action_str, re.DOTALL)
        if match:
            content = match.group(1)
            return f"finished(content='{content}')"
        return "finished()"
    
    # 未知类型，原样返回
    return action_str


def map_actions(
    actions_str: str,
    x1: int,
    y1: int,
    x2: Optional[int] = None,
    y2: Optional[int] = None,
    separator: str = '\n'
) -> str:
    """
    将多个 UI-TARS action 字符串映射为目标格式
    
    Args:
        actions_str: 原始 action 字符串（可能包含多个 action）
        x1: 起始点/点击点的 x 坐标
        y1: 起始点/点击点的 y 坐标
        x2: 结束点的 x 坐标 (仅 drag 操作需要)
        y2: 结束点的 y 坐标 (仅 drag 操作需要)
        separator: action 之间的分隔符，默认为 '\n'
    
    Returns:
        映射后的 action 字符串
    """
    # 分割多个 action
    actions = actions_str.split(separator)
    
    # 逐个映射
    mapped_actions = []
    for action in actions:
        action = action.strip()
        if action:
            mapped_action = map_action(action, x1, y1, x2, y2)
            mapped_actions.append(mapped_action)
    
    # 用换行符连接
    return separator.join(mapped_actions)


# ==================== 使用示例 ====================

if __name__ == "__main__":
    
    # 示例 1: click
    print("=" * 60)
    print("示例 1: click")
    print("-" * 60)
    input_str = "click(start_box='<|box_start|>(x=0.1348, y=0.8916)<box_end>')"
    output = map_action(input_str, x1=500, y1=400)
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 2: drag
    print("=" * 60)
    print("示例 2: drag")
    print("-" * 60)
    input_str = "drag(start_box='<|box_start|>(x=0.5688, y=0.9824)<|box_end|>', end_box='<|box_start|>(x=0.6005, y=0.9917)<|box_end|>')"
    output = map_action(input_str, x1=300, y1=300, x2=600, y2=600)
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 3: type
    print("=" * 60)
    print("示例 3: type")
    print("-" * 60)
    input_str = "type(content='search keyword')"
    output = map_action(input_str, x1=0, y1=0)  # type 不需要坐标
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 4: scroll
    print("=" * 60)
    print("示例 4: scroll")
    print("-" * 60)
    input_str = "scroll(start_box='<|box_start|>(x=0.5, y=0.4815)<|box_end|>', direction='down')"
    output = map_action(input_str, x1=300, y1=300)
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 5: hotkey
    print("=" * 60)
    print("示例 5: hotkey")
    print("-" * 60)
    input_str = "hotkey(key='ctrl c')"
    output = map_action(input_str, x1=0, y1=0)  # hotkey 不需要坐标
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 6: 多个 action
    print("=" * 60)
    print("示例 6: 多个 action (用换行分隔)")
    print("-" * 60)
    input_str = """click(start_box='<|box_start|>(x=0.1348, y=0.8916)<box_end>')
type(content='search keyword')"""
    output = map_actions(input_str, x1=500, y1=400)
    print(f"映射前:\n{input_str}")
    print(f"\n映射后:\n{output}")
    print()
    
    # 示例 7: wait
    print("=" * 60)
    print("示例 7: wait")
    print("-" * 60)
    input_str = "wait()"
    output = map_action(input_str, x1=0, y1=0)
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 8: finished
    print("=" * 60)
    print("示例 8: finished")
    print("-" * 60)
    input_str = "finished(content='Task completed successfully')"
    output = map_action(input_str, x1=0, y1=0)
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 9: left_double
    print("=" * 60)
    print("示例 9: left_double")
    print("-" * 60)
    input_str = "left_double(start_box='<|box_start|>(x=0.5, y=0.5)<|box_end|>')"
    output = map_action(input_str, x1=800, y1=600)
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
    print()
    
    # 示例 10: right_single
    print("=" * 60)
    print("示例 10: right_single")
    print("-" * 60)
    input_str = "right_single(start_box='<|box_start|>(x=0.3, y=0.7)<|box_end|>')"
    output = map_action(input_str, x1=200, y1=700)
    print(f"映射前: {input_str}")
    print(f"映射后: {output}")
